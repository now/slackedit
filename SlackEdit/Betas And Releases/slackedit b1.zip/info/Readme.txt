SlackEdit Readme File

================ T.O.C ================

	o Minimum Requirements
	o Installantion
	o What's New

============== END T.O.C ==============

Minimum Requirements:
	o comctl32.dll v4.71 or later
	o 600 kb free diskspace
	o 1 brain
	o a "good" ms windows system (not 3.1)
	o a will to edit text

Installation:
	1 Unzip SlackEdit.zip (with -d if you use pkzip)
	  into it's own directory.
	2 Start off SlackEdit.exe.
	3 Be happy.

What's New:
	Nothing. (First Public Release)
